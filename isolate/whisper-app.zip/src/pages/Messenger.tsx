import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { useAuth } from "@/hooks/use-auth";
import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageCircle, Search, Send, ArrowLeft, LogOut,
  UserPlus, Settings, Users, Mic, MicOff, Phone, PhoneOff,
  Video, VideoOff, X, Play, Pause, Hash, Volume2,
  Smile, Forward, Pin, PinOff, Edit3, MoreHorizontal,
  Sun, Moon, Shield, ShieldOff, Trash2, Check,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type View = "chats" | "contacts" | "settings" | "chat";

// ─── Constants ───

const EMOJI_LIST = ["😀","😂","😍","🥰","😎","🤩","😢","😭","😡","🤔","👍","👎","❤️","🔥","💯","✅","🎉","🙏","👋","💪","😱","🥺","😴","🤮","💀","👀","🫡","🤡","😈","😇"];

const QUICK_REACTIONS = ["❤️","😂","👍","🔥","😮","😢"];

// ─── Theme ───

function useTheme() {
  const [dark, setDark] = useState(() => localStorage.getItem("theme") === "dark");
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);
  return { dark, toggle: () => setDark((d) => !d) };
}

// ─── Sound ───

function playNotifSound() {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(660, ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.2);
    setTimeout(() => ctx.close(), 500);
  } catch {}
}

// ─── Helpers ───

function getInitials(name: string) {
  return name.slice(0, 2).toUpperCase();
}

function formatTime(ts?: number) {
  if (!ts) return "";
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" });
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

const convexUrl = import.meta.env.VITE_CONVEX_URL as string;
function fileUrl(storageId: string) { return `${convexUrl}/api/storage/${storageId}`; }

// ─── Avatar ───

function Avatar({ nickname, online, size = "md", avatarStorageId }: { nickname: string; online?: boolean; size?: "sm" | "md" | "lg"; avatarStorageId?: string | null }) {
  const sz = { sm: "w-8 h-8 text-xs", md: "w-10 h-10 text-sm", lg: "w-16 h-16 text-lg" }[size];
  const avatarUrl = useQuery(api.users.getAvatarUrl, avatarStorageId ? { storageId: avatarStorageId } : "skip");
  return (
    <div className="relative shrink-0">
      {avatarUrl ? (
        <img src={avatarUrl} alt={nickname} className={`${sz} rounded-full object-cover`} />
      ) : (
        <div className={`${sz} rounded-full bg-primary/15 text-primary font-semibold flex items-center justify-center`}>{getInitials(nickname)}</div>
      )}
      {online && <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-background" />}
    </div>
  );
}

// ─── Emoji Picker ───

function EmojiPicker({ onSelect, onClose }: { onSelect: (emoji: string) => void; onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="absolute bottom-full mb-2 left-0 z-40 bg-popover border border-border rounded-xl p-3 shadow-lg w-[280px]">
      <div className="grid grid-cols-8 gap-1">
        {EMOJI_LIST.map((e) => (
          <button key={e} onClick={() => { onSelect(e); onClose(); }} className="w-8 h-8 flex items-center justify-center text-lg hover:bg-muted rounded-lg transition-colors">{e}</button>
        ))}
      </div>
    </motion.div>
  );
}

// ─── Message Reactions ───

function MessageReactions({ reactions, currentUserId, onToggle }: { reactions?: Record<string, string[]>; currentUserId?: string; onToggle: (emoji: string) => void }) {
  if (!reactions || Object.keys(reactions).length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {Object.entries(reactions).map(([emoji, users]) => (
        <button key={emoji} onClick={() => onToggle(emoji)} className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs border transition-colors ${users.includes(currentUserId ?? "") ? "bg-primary/15 border-primary/30 text-primary" : "bg-muted/50 border-border/30 hover:bg-muted"}`}>
          <span>{emoji}</span>
          <span className="font-mono text-[10px]">{users.length}</span>
        </button>
      ))}
    </div>
  );
}

// ─── Quick Reaction Bar ───

function QuickReactions({ onReact, onEmojiPicker }: { onReact: (emoji: string) => void; onEmojiPicker: () => void }) {
  return (
    <div className="flex items-center gap-0.5 bg-popover border border-border rounded-full px-1 py-0.5 shadow-lg">
      {QUICK_REACTIONS.map((e) => (
        <button key={e} onClick={() => onReact(e)} className="w-7 h-7 flex items-center justify-center text-sm hover:bg-muted rounded-full transition-colors">{e}</button>
      ))}
      <button onClick={onEmojiPicker} className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:bg-muted rounded-full transition-colors"><Smile className="w-3.5 h-3.5" /></button>
    </div>
  );
}

// ─── Image Message ───

function ImageMessage({ storageId }: { storageId: string }) {
  const url = useQuery(api.chat.getStorageUrl, { storageId });
  if (!url) return <div className="w-48 h-32 bg-primary/10 rounded-xl animate-pulse" />;
  return (
    <a href={url} target="_blank" rel="noopener noreferrer">
      <img src={url} alt="Фото" className="max-w-[260px] max-h-[300px] rounded-xl object-cover cursor-pointer hover:opacity-90 transition-opacity" loading="lazy" />
    </a>
  );
}

// ─── Voice Recorder ───

function VoiceRecorder({ onSend }: { onSend: (blob: Blob, duration: number) => void }) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [preview, setPreview] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const startTimeRef = useRef(0);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        setPreview(blob);
        setPreviewUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
      };
      recorderRef.current = recorder;
      recorder.start();
      startTimeRef.current = Date.now();
      setRecording(true);
      setDuration(0);
      timerRef.current = setInterval(() => {
        setDuration(Math.floor((Date.now() - startTimeRef.current) / 1000));
      }, 200);
    } catch { console.error("Microphone access denied"); }
  };

  const stopRecording = () => {
    recorderRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const cancel = () => { setPreview(null); setPreviewUrl(""); setDuration(0); };

  const sendVoice = () => {
    if (preview) { onSend(preview, duration); setPreview(null); setPreviewUrl(""); setDuration(0); }
  };

  if (preview) {
    return (
      <div className="flex items-center gap-3 w-full">
        <button onClick={cancel} className="p-2 text-muted-foreground hover:text-red-500 transition-colors"><X className="w-4 h-4" /></button>
        <audio src={previewUrl} controls className="h-8 flex-1" />
        <span className="text-xs text-muted-foreground font-mono">{formatDuration(duration)}</span>
        <Button size="icon" className="w-8 h-8 rounded-full bg-primary" onClick={sendVoice}><Send className="w-3.5 h-3.5" /></Button>
      </div>
    );
  }

  if (recording) {
    return (
      <div className="flex items-center gap-3 w-full">
        <div className="flex items-center gap-2 text-red-500">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-xs font-mono">{formatDuration(duration)}</span>
        </div>
        <div className="flex-1 h-8 bg-card rounded-full overflow-hidden flex items-center px-4">
          <Volume2 className="w-3.5 h-3.5 text-red-500 animate-pulse" />
        </div>
        <Button size="icon" variant="destructive" className="w-8 h-8 rounded-full" onClick={stopRecording}><MicOff className="w-3.5 h-3.5" /></Button>
      </div>
    );
  }

  return (
    <Button size="icon" variant="ghost" className="shrink-0 text-muted-foreground hover:text-primary" onClick={startRecording}>
      <Mic className="w-5 h-5" />
    </Button>
  );
}

// ─── Audio Message Player ───

function AudioMessage({ storageId, isMe }: { storageId: string; isMe: boolean }) {
  const [playing, setPlaying] = useState(false);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const url = useQuery(api.chat.getStorageUrl, { storageId });

  const togglePlay = async () => {
    if (!audioRef.current || !url) return;
    if (playing) { audioRef.current.pause(); setPlaying(false); }
    else {
      try {
        audioRef.current.src = url;
        await audioRef.current.play();
        setPlaying(true);
      } catch { setError(true); }
    }
  };

  useEffect(() => {
    if (audioRef.current && url) {
      audioRef.current.src = url;
      audioRef.current.load();
    }
  }, [url]);

  if (error) return <span className="text-xs opacity-60">⚠ Ошибка воспроизведения</span>;

  return (
    <div className="flex items-center gap-2 min-w-[180px]">
      <button onClick={togglePlay} disabled={!url} className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-opacity ${!url ? "opacity-40" : ""} ${isMe ? "bg-primary-foreground/20 text-primary-foreground" : "bg-primary/20 text-primary"}`}>
        {playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
      </button>
      <audio ref={audioRef} onEnded={() => setPlaying(false)} onLoadedData={() => setReady(true)} preload="auto" style={{ display: "none" }} />
      <div className="flex-1 h-1 rounded-full bg-current/20 relative overflow-hidden">
        <div className={`absolute inset-y-0 left-0 rounded-full transition-all ${isMe ? "bg-primary-foreground/50" : "bg-primary/50"} ${playing ? "w-full animate-pulse" : ready ? "w-full opacity-30" : "w-1/3 opacity-20 animate-pulse"}`} />
      </div>
    </div>
  );
}

// ─── Forward Dialog ───

function ForwardDialog({ messageId, conversations, currentUserId, onForward, onClose }: { messageId: string; conversations: any[]; currentUserId?: string; onForward: (convoId: string) => void; onClose: () => void }) {
  const [search, setSearch] = useState("");
  const filtered = conversations.filter((c) => {
    const name = c.isGroup ? c.name : c.otherUser?.nickname ?? "";
    return name.toLowerCase().includes(search.toLowerCase());
  });
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-center justify-center" onClick={onClose}>
      <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl w-80 max-h-96 flex flex-col border border-border/40 overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 py-3 border-b border-border/30">
          <p className="text-sm font-semibold">Переслать в...</p>
          <Input placeholder="Найти диалог..." value={search} onChange={(e) => setSearch(e.target.value)} className="mt-2 bg-muted/50 border-0 text-sm" />
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.map((c) => (
            <button key={c._id} onClick={() => { onForward(c._id); onClose(); }} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/50 transition-colors text-left">
              {c.isGroup ? (
                <div className="w-10 h-10 rounded-full bg-primary/15 text-primary font-semibold flex items-center justify-center text-sm"><Users className="w-4 h-4" /></div>
              ) : (
                <Avatar nickname={c.otherUser?.nickname ?? "?"} size="md" avatarStorageId={c.otherUser?.avatar} />
              )}
              <span className="text-sm font-medium truncate">{c.isGroup ? c.name : c.otherUser?.nickname}</span>
            </button>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Create Group Dialog ───

function CreateGroupDialog({ contacts, onCreate, onClose }: { contacts: any[]; onCreate: (name: string, ids: string[]) => void; onClose: () => void }) {
  const [name, setName] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-center justify-center" onClick={onClose}>
      <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl w-80 max-h-96 flex flex-col border border-border/40 overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 py-3 border-b border-border/30">
          <p className="text-sm font-semibold">Новый групповой чат</p>
          <Input placeholder="Название группы..." value={name} onChange={(e) => setName(e.target.value)} className="mt-2 bg-muted/50 border-0 text-sm" autoFocus />
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {contacts.map((c) => (
            <button key={c._id} onClick={() => toggle(c._id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-left ${selected.has(c._id) ? "bg-primary/10" : "hover:bg-muted/50"}`}>
              <Avatar nickname={c.nickname ?? "?"} size="sm" avatarStorageId={c.avatar} />
              <span className="text-sm font-medium flex-1 truncate">{c.nickname}</span>
              {selected.has(c._id) && <Check className="w-4 h-4 text-primary" />}
            </button>
          ))}
        </div>
        <div className="px-4 py-3 border-t border-border/30">
          <Button onClick={() => { if (name.trim() && selected.size > 0) onCreate(name, [...selected]); }} disabled={!name.trim() || selected.size === 0} className="w-full">Создать ({selected.size})</Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Active Call Overlay ───

function ActiveCallOverlay({ conversationId, otherUser, callType, onEnd, isCaller }: { conversationId: string; otherUser: { _id?: string; nickname: string; online: boolean; avatar?: string }; callType: "audio" | "video"; onEnd: () => void; isCaller?: boolean }) {
  const [elapsed, setElapsed] = useState(0);
  const [mediaError, setMediaError] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [muted, setMuted] = useState(false);
  const [pcReady, setPcReady] = useState(false);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const onEndRef = useRef(onEnd);
  onEndRef.current = onEnd;
  const processedSignalsRef = useRef(new Set<string>());
  const pendingSignalsRef = useRef<any[]>([]);
  const sendSignal = useMutation(api.chat.sendSignal);
  const pollSignals = useQuery(api.chat.pollSignals);
  const consumeSignal = useMutation(api.chat.consumeSignal);

  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const processPendingSignals = useCallback(async () => {
    const pending = [...pendingSignalsRef.current];
    pendingSignalsRef.current = [];
    for (const signal of pending) {
      try {
        if (signal.type === "offer" && pcRef.current && !isCaller) {
          const data = JSON.parse(signal.payload);
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(data));
          const answer = await pcRef.current.createAnswer();
          await pcRef.current.setLocalDescription(answer);
          await sendSignal({ conversationId: conversationId as any, toUser: otherUser._id as any, type: "answer", payload: JSON.stringify({ sdp: answer.sdp, type: answer.type }) });
        } else if (signal.type === "answer" && pcRef.current) {
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(JSON.parse(signal.payload))).catch(() => {});
        } else if (signal.type === "ice-candidate" && pcRef.current) {
          await pcRef.current.addIceCandidate(new RTCIceCandidate(JSON.parse(signal.payload))).catch(() => {});
        }
        consumeSignal({ signalId: signal._id });
      } catch {}
    }
  }, [conversationId, otherUser._id, isCaller, sendSignal, consumeSignal]);

  useEffect(() => {
    let mounted = true;
    processedSignalsRef.current = new Set();
    pendingSignalsRef.current = [];
    setPcReady(false);
    const setup = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: callType === "video" });
        if (!mounted) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (localVideoRef.current && callType === "video") localVideoRef.current.srcObject = stream;
        const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun.l.google.com:5349" }, { urls: "stun:stun1.l.google.com:3478" }] });
        pcRef.current = pc;
        stream.getTracks().forEach(t => pc.addTrack(t, stream));
        pc.ontrack = (e) => {
          if (remoteVideoRef.current) remoteVideoRef.current.srcObject = e.streams[0];
          if (remoteAudioRef.current) { remoteAudioRef.current.srcObject = e.streams[0]; remoteAudioRef.current.play().catch(() => {}); }
        };
        pc.onicecandidate = async (e) => {
          if (e.candidate) {
            try { await sendSignal({ conversationId: conversationId as any, toUser: otherUser._id as any, type: "ice-candidate", payload: JSON.stringify(e.candidate.toJSON()) }); } catch {}
          }
        };
        pc.oniceconnectionstatechange = () => {
          if (pc.iceConnectionState === "failed") { if (mounted) onEndRef.current(); }
        };
        if (isCaller) {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sendSignal({ conversationId: conversationId as any, toUser: otherUser._id as any, type: "offer", payload: JSON.stringify({ sdp: offer.sdp, type: offer.type }) });
        }
        if (mounted) setPcReady(true);
      } catch {
        if (mounted) setMediaError(true);
      }
    };
    setup();
    return () => { mounted = false; streamRef.current?.getTracks().forEach(t => t.stop()); pcRef.current?.close(); pcRef.current = null; };
  }, [callType, retryKey]);

  useEffect(() => {
    if (!pollSignals) return;
    const processSignals = async () => {
      for (const signal of pollSignals) {
        if (processedSignalsRef.current.has(signal._id)) continue;
        if (signal.conversationId !== conversationId) continue;
        if (signal.type === "offer" && !pcRef.current && !isCaller) {
          if (!pendingSignalsRef.current.find(s => s._id === signal._id)) pendingSignalsRef.current.push(signal);
          continue;
        }
        processedSignalsRef.current.add(signal._id);
        try {
          if (signal.type === "offer" && pcRef.current && !isCaller) {
            const data = JSON.parse(signal.payload);
            await pcRef.current.setRemoteDescription(new RTCSessionDescription(data));
            const answer = await pcRef.current.createAnswer();
            await pcRef.current.setLocalDescription(answer);
            await sendSignal({ conversationId: conversationId as any, toUser: otherUser._id as any, type: "answer", payload: JSON.stringify({ sdp: answer.sdp, type: answer.type }) });
            consumeSignal({ signalId: signal._id });
          } else if (signal.type === "answer" && pcRef.current) {
            await pcRef.current.setRemoteDescription(new RTCSessionDescription(JSON.parse(signal.payload))).catch(() => {});
            consumeSignal({ signalId: signal._id });
          } else if (signal.type === "ice-candidate" && pcRef.current) {
            await pcRef.current.addIceCandidate(new RTCIceCandidate(JSON.parse(signal.payload))).catch(() => {});
            consumeSignal({ signalId: signal._id });
          } else {
            consumeSignal({ signalId: signal._id });
          }
        } catch {}
      }
    };
    processSignals();
  }, [pollSignals, pcReady, conversationId, isCaller, sendSignal, consumeSignal]);

  useEffect(() => {
    if (pcReady && pendingSignalsRef.current.length > 0) processPendingSignals();
  }, [pcReady, processPendingSignals]);

  const handleToggleMute = () => {
    if (streamRef.current) { streamRef.current.getAudioTracks().forEach(t => { t.enabled = muted; }); setMuted(!muted); }
  };
  const handleEnd = () => { streamRef.current?.getTracks().forEach(t => t.stop()); pcRef.current?.close(); onEnd(); };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-background/95 backdrop-blur flex flex-col items-center justify-center">
      <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />
      {callType === "video" && (
        <div className="absolute inset-4 overflow-hidden rounded-2xl">
          <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />
          <video ref={localVideoRef} autoPlay playsInline muted className="absolute bottom-4 right-4 w-32 h-24 rounded-xl object-cover border-2 border-border" />
        </div>
      )}
      <div className={`flex flex-col items-center gap-4 ${callType === "video" ? "relative z-10 mt-auto mb-20" : ""}`}>
        <Avatar nickname={otherUser.nickname} online={otherUser.online} size="lg" avatarStorageId={otherUser.avatar} />
        <div className="text-center">
          <p className="text-lg font-semibold">{otherUser.nickname}</p>
          {mediaError ? <p className="text-xs text-red-400 mt-1">⚠ Нет доступа к микрофону</p> : <p className="text-sm text-muted-foreground mt-1">{formatDuration(elapsed)}</p>}
        </div>
      </div>
      <div className="flex items-center gap-4 mt-12">
        {mediaError && <button onClick={() => { setMediaError(false); setRetryKey(k => k + 1); }} className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary/90 transition-colors"><Mic className="w-5 h-5" /></button>}
        <button onClick={handleToggleMute} className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${muted ? "bg-white/20 text-white" : "bg-white/10 text-white/70 hover:bg-white/20"}`}>
          {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>
        <button onClick={handleEnd} className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-600 transition-colors shadow-lg"><PhoneOff className="w-6 h-6" /></button>
        {callType === "audio" && <button className="w-14 h-14 rounded-full bg-white/10 text-white/70 flex items-center justify-center hover:bg-white/20 transition-colors"><Volume2 className="w-5 h-5" /></button>}
      </div>
    </motion.div>
  );
}

// ─── Incoming Call Overlay ───

function IncomingCallOverlay({ callerName, callType, onAccept, onReject }: { callerName: string; callType: "audio" | "video"; onAccept: () => void; onReject: () => void }) {
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  useEffect(() => {
    try {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const playTone = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.setValueAtTime(480, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.8);
      };
      playTone();
      intervalRef.current = setInterval(playTone, 1500);
    } catch {}
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); audioCtxRef.current?.close(); };
  }, []);
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-background/95 backdrop-blur flex flex-col items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <Avatar nickname={callerName} size="lg" />
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center animate-pulse"><Phone className="w-2.5 h-2.5 text-white" /></div>
        </div>
        <div className="text-center">
          <p className="text-lg font-semibold">{callerName}</p>
          <p className="text-sm text-muted-foreground mt-1">{callType === "video" ? "Видеозвонок" : "Голосовой звонок"}</p>
        </div>
      </div>
      <div className="flex items-center gap-12 mt-12">
        <div className="flex flex-col items-center gap-2">
          <button onClick={onReject} className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-600 transition-colors"><PhoneOff className="w-6 h-6" /></button>
          <span className="text-xs text-muted-foreground">Отклонить</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <button onClick={onAccept} className="w-16 h-16 rounded-full bg-emerald-500 flex items-center justify-center text-white hover:bg-emerald-600 transition-colors animate-pulse"><Phone className="w-6 h-6" /></button>
          <span className="text-xs text-muted-foreground">Принять</span>
        </div>
      </div>
    </motion.div>
  );
}

// ─── User Profile Dialog ───

function UserProfile({ userId, onClose, onStartChat, onBlock, isBlocked, isBlockedBy }: { userId: string; onClose: () => void; onStartChat: (id: string) => void; onBlock: (id: string) => void; isBlocked: boolean; isBlockedBy: boolean }) {
  const profile = useQuery(api.users.getUserById, { userId: userId as any });
  if (!profile) return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-center justify-center" onClick={onClose}>
      <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl p-8 w-80" onClick={(e) => e.stopPropagation()}><div className="w-2 h-2 rounded-full bg-primary/20 animate-pulse mx-auto" /></motion.div>
    </motion.div>
  );
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-center justify-center" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, y: 10 }} animate={{ scale: 1, y: 0 }} className="bg-card rounded-2xl p-6 w-80 border border-border/40" onClick={(e) => e.stopPropagation()}>
        <div className="flex flex-col items-center gap-3">
          <Avatar nickname={profile.nickname ?? "?"} online={profile.online} size="lg" avatarStorageId={profile.avatar} />
          <div className="text-center">
            <p className="text-lg font-semibold">{profile.nickname}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{profile.online ? <span className="text-emerald-500">в сети</span> : "не в сети"}</p>
          </div>
        </div>
        {profile.bio && (
          <div className="mt-4 px-2">
            <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">О себе</p>
            <p className="text-sm text-foreground/80">{profile.bio}</p>
          </div>
        )}
        <div className="mt-5 flex flex-col gap-2">
          {!isBlockedBy && <Button className="w-full" onClick={() => { onStartChat(profile._id); onClose(); }}>Написать</Button>}
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={onClose}>Закрыть</Button>
            {isBlocked ? (
              <Button variant="outline" className="flex-1 text-emerald-500" onClick={() => { onBlock(profile._id); onClose(); }}><ShieldOff className="w-3.5 h-3.5 mr-1" />Разблокировать</Button>
            ) : (
              <Button variant="outline" className="flex-1 text-red-500" onClick={() => { onBlock(profile._id); onClose(); }}><Shield className="w-3.5 h-3.5 mr-1" />Заблокировать</Button>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Chat View ───

function ChatView({ conversationId, onBack, onCall, onViewProfile }: { conversationId: string; onBack: () => void; onCall: (type: "audio" | "video") => void; onViewProfile: (id: string) => void }) {
  const [input, setInput] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const [replyToId, setReplyToId] = useState<string | null>(null);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editingMsgBody, setEditingMsgBody] = useState("");
  const [showForwardId, setShowForwardId] = useState<string | null>(null);
  const [hoveredMsgId, setHoveredMsgId] = useState<string | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const convo = useQuery(api.conversations.getById, { conversationId: conversationId as any });
  const messages = useQuery(api.chat.list, { conversationId: conversationId as any, limit: 200 });
  const pinnedMsg = useQuery(api.chat.getPinnedMessage, { conversationId: conversationId as any });
  const typingUsers = useQuery(api.chat.getTypingUsers, { conversationId: conversationId as any });
  const sendMessage = useMutation(api.chat.send);
  const markRead = useMutation(api.chat.markRead);
  const generateUploadUrl = useMutation(api.chat.generateUploadUrl);
  const editMessageMutation = useMutation(api.chat.editMessage);
  const pinMessageMutation = useMutation(api.chat.pinMessage);
  const unpinMessageMutation = useMutation(api.chat.unpinMessage);
  const addReactionMutation = useMutation(api.chat.addReaction);
  const forwardMessageMutation = useMutation(api.chat.forwardMessage);
  const setTypingMutation = useMutation(api.chat.setTyping);
  const clearTypingMutation = useMutation(api.chat.clearTyping);
  const currentUserId = useQuery(api.users.currentUser)?._id;
  const conversations = useQuery(api.conversations.list);

  useEffect(() => {
    if (conversationId) markRead({ conversationId: conversationId as any }).catch(() => {});
  }, [conversationId, markRead]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 100) + "px";
  }, [input]);

  const handleTyping = useCallback(() => {
    setTypingMutation({ conversationId: conversationId as any }).catch(() => {});
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => { clearTypingMutation().catch(() => {}); }, 3000);
  }, [conversationId, setTypingMutation, clearTypingMutation]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text) return;
    try {
      await sendMessage({ conversationId: conversationId as any, body: text, type: "text" });
      setInput(""); setReplyToId(null);
      clearTypingMutation().catch(() => {});
      textareaRef.current?.focus();
    } catch (err) { console.error("Send failed:", err); }
  };

  const handleEdit = async () => {
    if (!editingMsgId || !editingMsgBody.trim()) return;
    await editMessageMutation({ messageId: editingMsgId as any, body: editingMsgBody.trim() }).catch(() => {});
    setEditingMsgId(null); setEditingMsgBody("");
  };

  const handleForward = async (toConvoId: string) => {
    if (!showForwardId) return;
    await forwardMessageMutation({ messageId: showForwardId as any, toConversationId: toConvoId as any }).catch(() => {});
    setShowForwardId(null);
  };

  const handleReact = async (messageId: string, emoji: string) => {
    await addReactionMutation({ messageId: messageId as any, emoji }).catch(() => {});
  };

  const handlePin = async (messageId: string) => {
    await pinMessageMutation({ conversationId: conversationId as any, messageId: messageId as any }).catch(() => {});
    setActiveMenuId(null);
  };

  const handleSendVoice = async (blob: Blob, duration: number) => {
    try {
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": blob.type }, body: blob });
      const { storageId } = await result.json();
      await sendMessage({ conversationId: conversationId as any, body: "", type: "voice", file: { type: "audio", storageId, name: "voice.webm" }, duration });
    } catch (err) { console.error("Voice send failed:", err); }
  };

  // Sound notification for new messages
  const prevMsgCount = useRef(messages?.length ?? 0);
  useEffect(() => {
    if (messages && messages.length > prevMsgCount.current) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.senderId !== currentUserId) playNotifSound();
    }
    prevMsgCount.current = messages?.length ?? 0;
  }, [messages, currentUserId]);

  if (!convo) {
    return <div className="flex-1 flex items-center justify-center"><div className="w-2 h-2 rounded-full bg-primary/20 animate-pulse" /></div>;
  }

  const chatName = convo.isGroup ? convo.name : convo.otherUser?.nickname ?? "?";

  return (
    <div className="flex-1 flex flex-col h-full bg-background">
      {/* Pinned message bar */}
      {pinnedMsg && (
        <div className="px-4 py-2 bg-primary/5 border-b border-border/20 flex items-center gap-2 shrink-0 cursor-pointer" onClick={() => {
          const el = document.getElementById(`msg-${pinnedMsg._id}`);
          el?.scrollIntoView({ behavior: "smooth", block: "center" });
        }}>
          <Pin className="w-3.5 h-3.5 text-primary shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-[10px] text-primary font-medium">{pinnedMsg.senderName}</p>
            <p className="text-xs text-muted-foreground truncate">{pinnedMsg.body}</p>
          </div>
          <button onClick={(e) => { e.stopPropagation(); unpinMessageMutation({ conversationId: conversationId as any }); }} className="p-1 text-muted-foreground hover:text-foreground"><PinOff className="w-3.5 h-3.5" /></button>
        </div>
      )}

      <header className="flex items-center gap-3 px-5 py-3 bg-card border-b border-border/30 shrink-0">
        <button onClick={onBack} className="md:hidden p-1 text-muted-foreground hover:text-foreground"><ArrowLeft className="w-5 h-5" /></button>
        {convo.isGroup ? (
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="w-10 h-10 rounded-full bg-primary/15 text-primary font-semibold flex items-center justify-center text-sm"><Users className="w-4 h-4" /></div>
            <div>
              <p className="text-sm font-semibold">{convo.name}</p>
              <p className="text-[11px] text-muted-foreground">{convo.participants?.length} участников</p>
            </div>
          </div>
        ) : convo.otherUser && (
          <>
            <div className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer" onClick={() => convo.otherUser?._id && onViewProfile(convo.otherUser._id as string)}>
              <Avatar nickname={convo.otherUser.nickname ?? "?"} online={convo.otherUser.online} size="sm" avatarStorageId={convo.otherUser.avatar} />
              <div>
                <p className="text-sm font-semibold hover:underline">{convo.otherUser.nickname}</p>
                <p className="text-[11px] text-muted-foreground">{convo.otherUser.online ? <span className="text-emerald-500">в сети</span> : "не в сети"}</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => onCall("audio")} className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-lg hover:bg-muted"><Phone className="w-4 h-4" /></button>
              <button onClick={() => onCall("video")} className="p-2 text-muted-foreground hover:text-primary transition-colors rounded-lg hover:bg-muted"><Video className="w-4 h-4" /></button>
            </div>
          </>
        )}
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-1.5">
          {messages && messages.length === 0 && (
            <div className="text-center py-24">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4"><MessageCircle className="w-7 h-7 text-primary/40" /></div>
              <p className="text-sm font-medium text-foreground/60">Начните диалог</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Отправьте первое сообщение</p>
            </div>
          )}
          {messages?.map((msg) => {
            const isMe = msg.senderId === currentUserId;
            return (
              <div key={msg._id} id={`msg-${msg._id}`} className={`group relative flex ${isMe ? "justify-end" : "justify-start"}`}>
                {/* Message actions */}
                <div className={`absolute top-1 ${isMe ? "-left-8" : "-right-8"} opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5`}>
                  <button onClick={() => { setActiveMenuId(activeMenuId === msg._id ? null : msg._id); }} className="p-1 text-muted-foreground hover:text-foreground rounded"><MoreHorizontal className="w-3.5 h-3.5" /></button>
                </div>

                {/* Context menu */}
                {activeMenuId === msg._id && (
                  <div className={`absolute top-8 ${isMe ? "right-0" : "left-0"} z-30 bg-popover border border-border rounded-xl shadow-lg py-1 w-44`}>
                    <button onClick={() => { setActiveMenuId(null); setReplyToId(msg._id); textareaRef.current?.focus(); }} className="w-full px-3 py-2 text-xs text-left hover:bg-muted flex items-center gap-2"><Forward className="w-3.5 h-3.5" />Ответить</button>
                    <button onClick={() => { setActiveMenuId(null); setShowForwardId(msg._id); }} className="w-full px-3 py-2 text-xs text-left hover:bg-muted flex items-center gap-2"><Forward className="w-3.5 h-3.5" />Переслать</button>
                    {isMe && msg.type === "text" && (
                      <button onClick={() => { setActiveMenuId(null); setEditingMsgId(msg._id); setEditingMsgBody(msg.body); }} className="w-full px-3 py-2 text-xs text-left hover:bg-muted flex items-center gap-2"><Edit3 className="w-3.5 h-3.5" />Редактировать</button>
                    )}
                    <button onClick={() => { handlePin(msg._id); }} className="w-full px-3 py-2 text-xs text-left hover:bg-muted flex items-center gap-2"><Pin className="w-3.5 h-3.5" />{pinnedMsg?._id === msg._id ? "Открепить" : "Закрепить"}</button>
                    <QuickReactions onReact={(e) => { handleReact(msg._id, e); setActiveMenuId(null); }} onEmojiPicker={() => {}} />
                  </div>
                )}

                <div className="max-w-[75%]">
                  {/* Forwarded from */}
                  {msg.forwardedFrom && (
                    <div className="px-3 py-1 text-[10px] text-muted-foreground border-l-2 border-primary/30 mb-0.5">
                      Переслано от {msg.forwardedFrom.senderName}
                    </div>
                  )}
                  <div className={`px-4 py-2.5 text-sm leading-relaxed shadow-sm ${isMe ? "bg-primary text-primary-foreground rounded-2xl rounded-br-md" : "bg-card border border-border/30 text-foreground rounded-2xl rounded-bl-md"}`}>
                    {msg.type === "voice" && msg.file ? (
                      <AudioMessage storageId={msg.file.storageId} isMe={isMe} />
                    ) : msg.type === "image" && msg.file ? (
                      <ImageMessage storageId={msg.file.storageId} />
                    ) : (
                      <>
                        {editingMsgId === msg._id ? (
                          <div className="flex items-center gap-2">
                            <input value={editingMsgBody} onChange={(e) => setEditingMsgBody(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") handleEdit(); if (e.key === "Escape") setEditingMsgId(null); }} className="flex-1 bg-transparent outline-none text-sm" autoFocus />
                            <button onClick={handleEdit} className="text-emerald-500"><Check className="w-4 h-4" /></button>
                            <button onClick={() => setEditingMsgId(null)} className="text-muted-foreground"><X className="w-4 h-4" /></button>
                          </div>
                        ) : (
                          <span>{msg.body}{msg.edited && <span className="text-[10px] opacity-50 ml-1">(ред.)</span>}</span>
                        )}
                      </>
                    )}
                  </div>
                  {/* Reactions */}
                  <MessageReactions reactions={msg.reactions} currentUserId={currentUserId} onToggle={(emoji) => handleReact(msg._id, emoji)} />
                  {/* Group chat: show sender name */}
                  {convo.isGroup && !isMe && <p className="text-[10px] text-muted-foreground mt-0.5 ml-1">{msg.senderId}</p>}
                </div>
              </div>
            );
          })}
          {typingUsers && typingUsers.length > 0 && (
            <div className="text-xs text-muted-foreground/60 italic pl-1">{typingUsers.join(", ")} {typingUsers.length === 1 ? "печатает" : "печатают"}...</div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Reply preview */}
      {replyToId && (
        <div className="px-4 py-2 bg-primary/5 border-t border-border/20 flex items-center gap-2 shrink-0">
          <div className="w-0.5 h-8 bg-primary rounded-full shrink-0" />
          <p className="text-xs text-muted-foreground flex-1 truncate">Ответ на сообщение</p>
          <button onClick={() => setReplyToId(null)} className="p-1 text-muted-foreground hover:text-foreground"><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {/* Input */}
      <div className="shrink-0 border-t border-border/30 px-4 py-3 bg-card">
        <div className="max-w-2xl mx-auto flex items-end gap-2 relative">
          <VoiceRecorder onSend={handleSendVoice} />
          <div className="relative flex-1">
            <AnimatePresence>
              {showEmoji && <EmojiPicker onSelect={(e) => setInput((i) => i + e)} onClose={() => setShowEmoji(false)} />}
            </AnimatePresence>
            {editingMsgId && (
              <div className="flex items-center gap-2 mb-1 text-xs text-primary"><Edit3 className="w-3 h-3" /><span>Редактирование</span></div>
            )}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => { setInput(e.target.value); handleTyping(); }}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
              placeholder="Написать сообщение..."
              rows={1}
              className="w-full resize-none bg-muted/40 text-sm placeholder:text-muted-foreground/50 rounded-2xl px-4 py-2.5 border border-border/20 focus:border-primary/40 focus:bg-card outline-none transition-all"
              maxLength={5000}
            />
          </div>
          <button onClick={() => setShowEmoji(!showEmoji)} className="p-2 text-muted-foreground hover:text-primary transition-colors shrink-0"><Smile className="w-5 h-5" /></button>
          <Button type="submit" size="icon" disabled={!input.trim()} className="shrink-0 w-9 h-9 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-20 transition-all mb-0.5 shadow-sm" onClick={handleSend}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Forward dialog */}
      <AnimatePresence>
        {showForwardId && conversations && (
          <ForwardDialog messageId={showForwardId} conversations={conversations} currentUserId={currentUserId} onForward={handleForward} onClose={() => setShowForwardId(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Contacts Panel ───

function ContactsPanel({ onStartChat, onViewProfile, onStartGroup }: { onStartChat: (id: string) => void; onViewProfile: (id: string) => void; onStartGroup: () => void }) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const contacts = useQuery(api.contacts.list);
  const searchUsers = useQuery(api.contacts.searchUsers, search.length >= 2 ? { query: search } : "skip");
  const addContact = useMutation(api.contacts.add);

  useEffect(() => { if (searchUsers) setSearchResults(searchUsers); }, [searchUsers]);

  const handleAdd = async (userId: string) => {
    try { await addContact({ contactId: userId as any }); setSearch(""); setSearchResults([]); } catch {}
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border/40 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Найти по нику..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 bg-muted/50 border-0 focus-visible:ring-1 focus-visible:ring-primary/30" />
        </div>
        <Button size="icon" variant="ghost" className="shrink-0 text-muted-foreground hover:text-primary" onClick={onStartGroup}><Users className="w-4 h-4" /></Button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {search.length >= 2 && searchResults.length > 0 && (
          <div>
            <p className="px-4 py-2 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Результаты</p>
            {searchResults.map((user) => (
              <div key={user._id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/50 cursor-pointer transition-colors">
                <div onClick={(e) => { e.stopPropagation(); onViewProfile(user._id); }}><Avatar nickname={user.nickname} online={user.online} avatarStorageId={user.avatar} /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user.nickname}</p>
                  {user.bio && <p className="text-xs text-muted-foreground truncate">{user.bio}</p>}
                </div>
                <Button size="sm" variant="outline" onClick={() => handleAdd(user._id)} className="shrink-0"><UserPlus className="w-3.5 h-3.5 mr-1" />Добавить</Button>
              </div>
            ))}
          </div>
        )}
        {contacts && contacts.length > 0 && (
          <div>
            <p className="px-4 py-2 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Контакты</p>
            {contacts.map((c) => (
              <div key={c._id} onClick={() => onStartChat(c._id)} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/50 cursor-pointer transition-colors">
                <div onClick={(e) => { e.stopPropagation(); onViewProfile(c._id); }}><Avatar nickname={c.nickname ?? "?"} online={c.online} avatarStorageId={c.avatar} /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{c.nickname}</p>
                  <p className="text-xs text-muted-foreground">{c.online ? <span className="text-emerald-500">в сети</span> : "не в сети"}</p>
                </div>
              </div>
            ))}
          </div>
        )}
        {search.length < 2 && (!contacts || contacts.length === 0) && (
          <div className="text-center py-20">
            <UserPlus className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Пока нет контактов</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Найдите людей по нику</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Settings ───

function SettingsPanel({ theme }: { theme: { dark: boolean; toggle: () => void } }) {
  const user = useQuery(api.users.currentUser);
  const avatarUrl = useQuery(api.users.getAvatarUrl, user?.avatar ? { storageId: user.avatar } : "skip");
  const blockedUsers = useQuery(api.users.getBlockedUsers);
  const unblockUser = useMutation(api.users.unblockUser);
  const [nickname, setNickname] = useState("");
  const [bio, setBio] = useState("");
  const [initialized, setInitialized] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [uploading, setUploading] = useState(false);
  const setNicknameMutation = useMutation(api.users.setNickname);
  const updateProfile = useMutation(api.users.updateProfile);
  const generateAvatarUploadUrl = useMutation(api.users.generateAvatarUploadUrl);
  const setAvatarMutation = useMutation(api.users.setAvatar);
  const { signOut } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user && !initialized) {
      setNickname(user.nickname ?? "");
      setBio(user.bio ?? "");
      setInitialized(true);
    }
  }, [user, initialized]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateAvatarUploadUrl();
      const result = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
      const { storageId } = await result.json();
      await setAvatarMutation({ storageId });
      setMsg("Аватар обновлён!");
    } catch (err) { setMsg(err instanceof Error ? err.message : "Ошибка загрузки"); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ""; }
  };

  const handleSave = async () => {
    setSaving(true); setMsg("");
    try {
      if (nickname !== user?.nickname) await setNicknameMutation({ nickname });
      await updateProfile({ bio });
      setMsg("Сохранено!");
    } catch (err) { setMsg(err instanceof Error ? err.message : "Ошибка"); }
    finally { setSaving(false); }
  };

  if (!user) return null;

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border/40"><h2 className="text-sm font-semibold">Настройки</h2></div>
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        <div className="flex flex-col items-center gap-3">
          <button onClick={() => fileInputRef.current?.click()} className="relative group cursor-pointer" disabled={uploading}>
            {avatarUrl ? (
              <img src={avatarUrl} alt="Аватар" className="w-16 h-16 rounded-full object-cover border-2 border-border" />
            ) : (
              <Avatar nickname={user.nickname ?? user.email ?? "?"} online={true} size="lg" avatarStorageId={user.avatar} />
            )}
            <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white text-[10px] font-medium">{uploading ? "..." : "Фото"}</span>
            </div>
          </button>
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
          <p className="text-sm text-muted-foreground">{user.email}</p>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Никнейм</label>
            <Input value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="ваш_ник" className="bg-card" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">О себе</label>
            <Input value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Расскажите о себе..." className="bg-card" maxLength={160} />
          </div>
          <Button onClick={handleSave} disabled={saving} className="w-full">{saving ? "Сохранение..." : "Сохранить"}</Button>
          {msg && <p className={`text-xs text-center ${msg === "Сохранено!" || msg === "Аватар обновлён!" ? "text-emerald-500" : "text-red-500"}`}>{msg}</p>}
        </div>
        {/* Theme toggle */}
        <div className="flex items-center justify-between py-3 border-y border-border/30">
          <div className="flex items-center gap-2">
            {theme.dark ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            <span className="text-sm">{theme.dark ? "Тёмная тема" : "Светлая тема"}</span>
          </div>
          <button onClick={theme.toggle} className={`w-10 h-6 rounded-full transition-colors relative ${theme.dark ? "bg-primary" : "bg-muted"}`}>
            <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${theme.dark ? "translate-x-5" : "translate-x-1"}`} />
          </button>
        </div>
        {/* Blocked users */}
        {blockedUsers && blockedUsers.length > 0 && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Заблокированные</p>
            {blockedUsers.map((u) => (
              <div key={u._id} className="flex items-center gap-3 py-2">
                <Avatar nickname={u.nickname ?? "?"} size="sm" avatarStorageId={u.avatar} />
                <span className="text-sm flex-1">{u.nickname}</span>
                <Button size="sm" variant="ghost" onClick={() => unblockUser({ targetUserId: u._id as any })} className="text-xs text-primary">Разблокировать</Button>
              </div>
            ))}
          </div>
        )}
        <div className="pt-4 border-t border-border/40">
          <Button variant="outline" className="w-full text-red-500 hover:text-red-500" onClick={() => signOut()}>
            <LogOut className="w-4 h-4 mr-2" />Выйти
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Nickname Setup ───

function NicknameSetup() {
  const [nickname, setNickname] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const setNicknameMutation = useMutation(api.users.setNickname);

  const handleSave = async () => {
    setLoading(true); setError("");
    try { await setNicknameMutation({ nickname }); window.location.reload(); }
    catch (err) { setError(err instanceof Error ? err.message : "Ошибка"); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-sm space-y-6 px-6">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4"><Hash className="w-6 h-6 text-primary" /></div>
          <h1 className="text-2xl font-bold">Выберите никнейм</h1>
          <p className="mt-2 text-sm text-muted-foreground">Так вас будут видеть другие пользователи.</p>
        </div>
        <div className="space-y-4">
          <Input value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="ваш_ник" className="text-center text-lg" autoFocus />
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          <Button onClick={handleSave} disabled={loading || nickname.length < 3} className="w-full">{loading ? "Сохранение..." : "Продолжить"}</Button>
        </div>
      </div>
    </div>
  );
}

// ─── Caller Ringing Overlay ───

function CallerRingingOverlay({ otherUser, callType, onCancel }: { otherUser: { nickname: string; online: boolean }; callType: "audio" | "video"; onCancel: () => void }) {
  const [dots, setDots] = useState("");
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  useEffect(() => {
    const iv = setInterval(() => setDots(d => d.length >= 3 ? "" : d + "."), 500);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    try {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const playTone = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(425, ctx.currentTime);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.4);
      };
      playTone();
      intervalRef.current = setInterval(playTone, 3000);
    } catch {}
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); audioCtxRef.current?.close(); };
  }, []);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-background/95 backdrop-blur flex flex-col items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Avatar nickname={otherUser.nickname} online={otherUser.online} size="lg" />
        <div className="text-center">
          <p className="text-lg font-semibold">{otherUser.nickname}</p>
          <p className="text-sm text-muted-foreground mt-1">{callType === "video" ? "Видеозвонок" : "Голосовой звонок"}{dots}</p>
        </div>
      </div>
      <div className="flex items-center gap-6 mt-12">
        <button onClick={onCancel} className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-600 transition-colors"><PhoneOff className="w-6 h-6" /></button>
      </div>
    </motion.div>
  );
}

// ─── Main Messenger ───

export default function Messenger() {
  const { user, isLoading } = useAuth();
  const [view, setView] = useState<View>("chats");
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [outgoingCallConvoId, setOutgoingCallConvoId] = useState<string | null>(null);
  const [profileUserId, setProfileUserId] = useState<string | null>(null);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const theme = useTheme();

  const conversations = useQuery(api.conversations.list);
  const contacts = useQuery(api.contacts.list);
  const createConversation = useMutation(api.conversations.getOrCreate);
  const createGroupMutation = useMutation(api.conversations.createGroup);
  const heartbeat = useMutation(api.users.heartbeat);
  const initiateCall = useMutation(api.chat.initiateCall);
  const acceptCallMutation = useMutation(api.chat.acceptCall);
  const rejectCallMutation = useMutation(api.chat.rejectCall);
  const endCallMutation = useMutation(api.chat.endCall);
  const blockUserMutation = useMutation(api.users.blockUser);
  const isBlockedQuery = useQuery(api.users.isBlocked, profileUserId ? { targetUserId: profileUserId as any } : "skip");
  const isBlockedByQuery = useQuery(api.users.isBlockedBy, profileUserId ? { targetUserId: profileUserId as any } : "skip");

  useEffect(() => {
    if (!user) return;
    heartbeat().catch(() => {});
    const iv = setInterval(() => heartbeat().catch(() => {}), 30000);
    return () => clearInterval(iv);
  }, [user, heartbeat]);

  // Sound on incoming call
  const prevIncomingRef = useRef<string | null>(null);
  const incomingCall = conversations?.find(c =>
    c.callState === "ringing" &&
    c.callCaller !== user?._id &&
    c.otherUser
  );
  useEffect(() => {
    if (incomingCall && incomingCall._id !== prevIncomingRef.current) {
      playNotifSound();
      prevIncomingRef.current = incomingCall._id;
    }
    if (!incomingCall) prevIncomingRef.current = null;
  }, [incomingCall]);

  const connectedCall = conversations?.find(c => c.callState === "connected" && c.otherUser);
  const outgoingRingingCall = conversations?.find(c => c._id === outgoingCallConvoId && c.callState === "ringing" && c.callCaller === user?._id && c.otherUser);

  useEffect(() => {
    if (incomingCall) {
      const iv = setInterval(() => { try { navigator.vibrate?.([200, 100, 200]); } catch {} }, 1500);
      return () => clearInterval(iv);
    }
  }, [incomingCall]);

  useEffect(() => {
    if (outgoingCallConvoId && !outgoingRingingCall && !connectedCall) setOutgoingCallConvoId(null);
  }, [outgoingCallConvoId, outgoingRingingCall, connectedCall]);

  const handleStartChat = async (otherUserId: string) => {
    try {
      const { conversationId } = await createConversation({ otherUserId: otherUserId as any });
      setActiveChat(conversationId);
      setView("chat");
    } catch {}
  };

  const handleCreateGroup = async (name: string, ids: string[]) => {
    try {
      const { conversationId } = await createGroupMutation({ name, participantIds: ids as any });
      setActiveChat(conversationId);
      setView("chat");
      setShowCreateGroup(false);
    } catch {}
  };

  const handleCall = async (type: "audio" | "video") => {
    if (!activeChat) return;
    try { await initiateCall({ conversationId: activeChat as any, callType: type }); setOutgoingCallConvoId(activeChat); } catch {}
  };

  const handleCancelOutgoing = async (convoId: string) => {
    try { await rejectCallMutation({ conversationId: convoId as any }); } catch {}
    setOutgoingCallConvoId(null);
  };

  const handleAcceptCall = async (convoId: string) => { try { await acceptCallMutation({ conversationId: convoId as any }); } catch {} };
  const handleRejectCall = async (convoId: string) => { try { await rejectCallMutation({ conversationId: convoId as any }); } catch {} };
  const handleEndCall = async () => {
    if (connectedCall) await endCallMutation({ conversationId: connectedCall._id as any }).catch(() => {});
    setOutgoingCallConvoId(null);
  };

  const handleBlock = async (targetUserId: string) => {
    try { await blockUserMutation({ targetUserId: targetUserId as any }); } catch {}
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><div className="w-2 h-2 rounded-full bg-primary/20 animate-pulse" /></div>;
  }

  if (user && !user.nickname) return <NicknameSetup />;

  return (
    <div className="h-screen flex bg-muted/30 overflow-hidden">
      <aside className={`w-80 bg-card border-r border-border/30 flex flex-col shrink-0 ${view === "chat" ? "hidden md:flex" : "flex"}`}>
        <div className="px-4 py-3.5 flex items-center justify-between border-b border-border/40 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-sm">
              <MessageCircle className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold tracking-tight">Whisper</span>
          </div>
          <div className="flex items-center gap-0.5 bg-muted/50 rounded-xl p-0.5">
            {([[ "chats", MessageCircle, "Чаты"], ["contacts", Users, "Люди"], ["settings", Settings, "Настройки"]] as const).map(([v, Icon, label]) => (
              <button key={v} onClick={() => setView(v)} className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-all flex items-center gap-1.5 ${view === v ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-hidden">
          {view === "chats" && (
            <div className="h-full flex flex-col">
              <div className="px-4 py-2">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground/60" />
                  <Input placeholder="Найти диалог..." className="pl-9 bg-muted/50 text-sm border-0 focus-visible:ring-1 focus-visible:ring-primary/30" />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {conversations && conversations.length === 0 && (
                  <div className="text-center py-16">
                    <MessageCircle className="w-8 h-8 text-muted-foreground/20 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">Пока нет диалогов</p>
                    <button onClick={() => setView("contacts")} className="mt-2 text-xs text-primary hover:underline">Добавьте контакты</button>
                  </div>
                )}
                {conversations?.map((c) => (
                  <div key={c._id} onClick={() => { setActiveChat(c._id); setView("chat"); }} className={`flex items-center gap-3 px-4 py-3.5 cursor-pointer transition-all ${activeChat === c._id ? "bg-primary/5 border-l-2 border-primary" : "hover:bg-muted/50 border-l-2 border-transparent"}`}>
                    {c.isGroup ? (
                      <>
                        <div className="w-10 h-10 rounded-full bg-primary/15 text-primary font-semibold flex items-center justify-center text-sm shrink-0"><Users className="w-4 h-4" /></div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium truncate">{c.name}</p>
                            <span className="text-[10px] text-muted-foreground ml-2 shrink-0">{formatTime(c.lastMessageAt)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">{c.lastMessage ?? "Нет сообщений"}</p>
                        </div>
                      </>
                    ) : c.otherUser && (
                      <>
                        <div className="relative">
                          <div onClick={(e) => { e.stopPropagation(); if (c.otherUser?._id) setProfileUserId(c.otherUser._id as string); }}><Avatar nickname={c.otherUser.nickname ?? "?"} online={c.otherUser.online} avatarStorageId={c.otherUser.avatar} /></div>
                          {c.callState === "ringing" && c.callCaller !== user?._id && <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center animate-pulse"><Phone className="w-2 h-2 text-white" /></div>}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium truncate">{c.otherUser.nickname}</p>
                            <span className="text-[10px] text-muted-foreground ml-2 shrink-0">{formatTime(c.lastMessageAt)}</span>
                          </div>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">
                            {c.callState === "ringing" && c.callCaller !== user?._id ? <span className="text-emerald-500 font-medium">📞 Входящий звонок...</span> : c.lastMessage ?? "Нет сообщений"}
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          {view === "contacts" && <ContactsPanel onStartChat={handleStartChat} onViewProfile={(id) => setProfileUserId(id)} onStartGroup={() => setShowCreateGroup(true)} />}
          {view === "settings" && <SettingsPanel theme={theme} />}
        </div>
      </aside>
      <main className="flex-1 flex flex-col min-w-0">
        {view === "chat" && activeChat ? (
          <ChatView conversationId={activeChat} onBack={() => { setView("chats"); setActiveChat(null); }} onCall={handleCall} onViewProfile={(id) => setProfileUserId(id)} />
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto mb-4"><MessageCircle className="w-8 h-8 text-muted-foreground/30" /></div>
              <p className="text-sm font-medium text-foreground/50">Выберите диалог</p>
              <p className="text-xs text-muted-foreground/50 mt-1">или начните новый в контактах</p>
            </div>
          </div>
        )}
      </main>

      <AnimatePresence>
        {incomingCall && !connectedCall && <IncomingCallOverlay callerName={incomingCall.otherUser?.nickname ?? "Неизвестный"} callType={incomingCall.callType ?? "audio"} onAccept={() => handleAcceptCall(incomingCall._id)} onReject={() => handleRejectCall(incomingCall._id)} />}
      </AnimatePresence>
      <AnimatePresence>
        {outgoingRingingCall && <CallerRingingOverlay otherUser={{ nickname: outgoingRingingCall.otherUser?.nickname ?? "Неизвестный", online: outgoingRingingCall.otherUser?.online ?? false }} callType={outgoingRingingCall.callType ?? "audio"} onCancel={() => handleCancelOutgoing(outgoingRingingCall._id)} />}
      </AnimatePresence>
      <AnimatePresence>
        {connectedCall && <ActiveCallOverlay conversationId={connectedCall._id} otherUser={{ nickname: connectedCall.otherUser?.nickname ?? "?", online: connectedCall.otherUser?.online ?? false, avatar: connectedCall.otherUser?.avatar }} callType={connectedCall.callType ?? "audio"} onEnd={handleEndCall} isCaller={connectedCall.callCaller === user?._id} />}
      </AnimatePresence>
      <AnimatePresence>
        {profileUserId && <UserProfile userId={profileUserId} onClose={() => setProfileUserId(null)} onStartChat={(id) => { setProfileUserId(null); handleStartChat(id); }} onBlock={handleBlock} isBlocked={isBlockedQuery ?? false} isBlockedBy={isBlockedByQuery ?? false} />}
      </AnimatePresence>
      <AnimatePresence>
        {showCreateGroup && contacts && <CreateGroupDialog contacts={contacts} onCreate={handleCreateGroup} onClose={() => setShowCreateGroup(false)} />}
      </AnimatePresence>
    </div>
  );
}
